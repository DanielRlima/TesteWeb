package runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		//caminho das fetures
				features = "src/test/resource/features/",
				
				// pacote das class de testes
				glue = "tests",
				
				//nome da tag no arquivo gherkins para executar os casos de testes correspondentes
				tags = "@executa",
				
				//formatar visualização do código no console | report html
				plugin = {"pretty","html:target/report.html"},
				
				// Valida se existem features sem steps implementados, padrão deixar como false
				dryRun = false
	
		
		
		
		
		
		)
















public class Executa {

}
