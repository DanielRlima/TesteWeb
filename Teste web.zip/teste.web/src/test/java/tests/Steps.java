package tests;


import java.io.IOException;

import elementos.Elementos;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Metodos;

public class Steps {
	
	Metodos metodos = new Metodos();
	Elementos elementos = new Elementos();

	@Given("que eu acessa {string}")
	public void que_eu_acessa(String url) throws InterruptedException {
		
		metodos.abrirNavegador(url, "CHROME");
		metodos.clicar(elementos.abrirConta);
			
	}

	@When("preencher os campos obrigatorios")
	public void preencher_os_campos_obrigatorios() throws InterruptedException {
		metodos.preencher(elementos.nome,"Joao Luis");
		metodos.preencher(elementos.telefone,"0159993105050");
		metodos.preencher(elementos.email, "teste@yahoo.com.br");	
		metodos.preencher(elementos.cpf, "346.062.260-13");
		metodos.pause(3000);
	}

	@Then("formulario de conta enviado com sucesso")
	public void formulario_de_conta_enviado_com_sucesso() throws InterruptedException, IOException {
		metodos.clicar(elementos.btnEnviar);
		metodos.pause(3000);
		metodos.screenshot("AbrirConta");
		metodos.fechar();
	}

}
