package elementos;

import org.openqa.selenium.By;

public class Elementos {

	public By abrirConta = By.cssSelector("#section-3 > div > div.content.right > div > a");
	public By nome = By.id("nome");
	public By telefone = By.id("telefone");
	public By email = By.id("email");
	public By cpf = By.id("cpf");
	public By btnEnviar = By.id("btnEnviar");
	
}
